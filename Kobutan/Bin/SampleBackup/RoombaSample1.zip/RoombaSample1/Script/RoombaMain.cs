﻿// エントリポイント
void RoombaMain()
{
    OutputString("START!");
    // 1秒間 前進
    Forward();        // 前進
    Sleep(1000);      // 次のステップに移るまで1秒待つ
    Stop();           // ストップ
    // 2.5秒間 左旋回
    TurnRight();       // 左旋回
    Sleep(1500);      // 次のステップに移るまで2.5秒待つ
    Stop();           // ストップ
    // 1秒間 前進
    Forward();        // 前進
    Sleep(1000);      // 次のステップに移るまで1秒待つ
    Stop();           // ストップ
    OutputString("STOP!!");
    Exit();
}
