﻿// エントリポイント
void RoombaMain()
{
	//CLEANボタンを押している間音を鳴らす
	if(CleanButton == 1)
	{
		//LEDの点灯
        SetLEDColor('Y');
		//ドの音を鳴らす
		Sound_DO();
	}
	else//押していないとき
	{
		//LEDの消灯
        SetLEDColor('N');
	}
}
