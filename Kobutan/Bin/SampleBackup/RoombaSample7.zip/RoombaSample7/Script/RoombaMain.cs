﻿// エントリポイント
void RoombaMain()
{
	//前側面に搭載されている6個の赤外線バンパの内どれかが障害物を検知すると停止する
	if((LightBumpLeft > 50) || (LightBumpFrontLeft > 50) ||
	(LightBumpCenterLeft > 50) || (LightBumpRight > 50) ||
	(LightBumpFrontRight > 50) || (LightBumpCenterRight > 50))
	{
		//停止
        Stop();
	}
	else//それ以外
	{
		//前進
        Forward();
	}
}
