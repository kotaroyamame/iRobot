﻿// エントリポイント
void RoombaMain()
{
	//右バンパが押されると停止する
	if(RightBumper == 1)
	{
		//停止
        Stop();
	}
	else//それ以外
	{
		//前進
        Forward();
	}
}
